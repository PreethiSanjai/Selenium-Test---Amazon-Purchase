package co.uk.amazon.page;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import co.uk.amazon.base.PageBase;
import co.uk.amazon.util.PropertiesUtil;

public class SearchSelectProduct extends PageBase {

	@FindBy(id = "twotabsearchtextbox")
	public WebElement searchBoxWE;

	@FindBy(xpath = "//input[@type='submit']")
	public WebElement goButtonWE;

	@FindBy(xpath = "//*[@id='reg-login-form']/form/div/p/input")
	public WebElement loginWE;

	@FindBy(linkText = "Login")
	public WebElement loginLinkWE;

	
	@FindBy(xpath = "//*[@id='result_2']/div/div/div/div[2]/div[1]/a/h2")
	public WebElement productWE;
	
	
	public SearchSelectProduct(WebDriver driver) throws Exception {
		super(driver);
		driver.manage().deleteAllCookies();
		driver.get(
				"http://www.amazon.co.uk");
		driver.manage().window().maximize();
	}

	public void searchProduct(String product) {
		assertTrue("Search Box TextField is not displayed",
				searchBoxWE.isDisplayed());
		enter(searchBoxWE, product);
		assertTrue("Go Button is not displayed", goButtonWE.isDisplayed());
		click(goButtonWE);
		
	}
	
	public AddEditCart clickThirdPhone() throws Exception {
		assertTrue("Products are not listed", productWE.isDisplayed());
		productWE.click();

		return new AddEditCart(driver);
	}

	
}
package co.uk.amazon.page;

import org.openqa.selenium.WebDriver;
import co.uk.amazon.base.PageBase;

public class DeliveryOptionsPage extends PageBase {

	public DeliveryOptionsPage(WebDriver driver) throws Exception {
		super(driver);

	}

}